﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using ProyectoFinal.DAL.Context;
using ProyectoFinal.DAL.Interfaces;
using ProyectoFinal.ML.Entities;
using System.Threading;

namespace ProyectoFinal.DAL.Repositories
{
    public class TareaRepository : ItareasRepository
    {

        private readonly ProyectoFinalTareaDbContext _dbContext;

        public TareaRepository(ProyectoFinalTareaDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Tarea> Insert(Tarea tarea)
        {
            EntityEntry <Tarea> insertedTarea = await _dbContext.Tareas.AddAsync(tarea);
            await _dbContext.SaveChangesAsync();
            return insertedTarea.Entity;

        }

        public async Task<IEnumerable<Tarea>> GetAll()
        {
            var tareas = await _dbContext.Tareas.ToListAsync();
            return tareas;
              
        }

        public async Task<Tarea> GetById(int id)
        {
            return await _dbContext.Tareas.Where(x => x.IdTarea == id).SingleOrDefaultAsync();
        }

        public async Task<Tarea> Update(Tarea tarea)
        {
            var existingTarea = await _dbContext.Tareas.FindAsync(tarea.IdTarea);

            if (existingTarea == null)
            {
                return null;
            }

            _dbContext.Entry(existingTarea).CurrentValues.SetValues(tarea);

            await _dbContext.SaveChangesAsync(); // Guarda los cambios en la base de datos
            return existingTarea;
        }

        public async Task<Tarea> Delete(int id)
        {
            var existingTarea = await _dbContext.Tareas.FindAsync(id);

            if (existingTarea == null)
            {
                return null;
            }

            _dbContext.Tareas.Remove(existingTarea);

            return existingTarea;

        }
    }
}

