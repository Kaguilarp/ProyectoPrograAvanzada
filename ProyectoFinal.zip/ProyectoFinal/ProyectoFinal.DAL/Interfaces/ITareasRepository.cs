﻿using ProyectoFinal.ML.Entities;    

namespace ProyectoFinal.DAL.Interfaces
{
    public interface ItareasRepository
    {
        Task<IEnumerable<Tarea>> GetAll();

        Task<Tarea> GetById(int id);

        Task <Tarea> Insert (Tarea tarea);

        Task <Tarea> Update(Tarea tarea);

        Task <Tarea> Delete(int id);
    }
}
