﻿using System;
using System.Collections.Generic;

namespace ProyectoFinal.ML.Entities;

public partial class LogTarea
{
    public int IdLog { get; set; }

    public int IdTarea { get; set; }

    public DateTime FechaInicio { get; set; }

    public DateTime? FechaFin { get; set; }

    public string Estado { get; set; } = null!;

    public string? MensajeError { get; set; }

    public virtual Tarea IdTareaNavigation { get; set; } = null!;
}
