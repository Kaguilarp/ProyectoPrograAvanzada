﻿using ProyectoFinal.DAL.Interfaces;
using ProyectoFInal.BLL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFInal.BLL.Servicios
{
    public class TareasService : ITareasService
    {
        private readonly ItareasRepository _tareaRepository;

        public TareasService(ItareasRepository tareaRepository)
        {
            _tareaRepository = tareaRepository;
        }

        public async Task<List<TareaRsponseDto>> Get()
        {
            try
            {
                var tareas = await _tareaRepository.GetAll();
                return tareas;
            }
            catch
            {
                throw;
            }
        }
    }
}
