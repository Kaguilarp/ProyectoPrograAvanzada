﻿using ProyectoFinal.ML.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFInal.BLL.Dtos.Responses
{
    public class TareaResponse
    {

        public int IdTarea { get; set; }

        public string Titulo { get; set; } = null!;

        public string? Descripcion { get; set; }

        public string Prioridad { get; set; } = null!;

        public string Estado { get; set; } = null!;

        public DateTime FechaCreacion { get; set; }

        public DateTime? FechaEjecucion { get; set; }

        public int IdUsuario { get; set; }

        public virtual Usuario IdUsuarioNavigation { get; set; } = null!;

        public virtual ICollection<LogTarea> LogTareas { get; set; } = new List<LogTarea>();
    }
}
