﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFinal.ML.Entities
{
    [Table("Tarea")]
    public class Tarea
    {
        [Key]
        public int IdTarea { get; set; }

        [Required]
        [StringLength(200)]
        public string? Titulo { get; set; }

        [StringLength(1000)]
        public string? Descripcion { get; set; }

        [Required]
        [StringLength(10)]
        public string? Prioridad { get; set; }

        [Required]
        [StringLength(20)]
        public string? Estado { get; set; }

        public DateTime FechaCreacion { get; set; } = DateTime.Now;

        public DateTime? FechaEjecucion { get; set; }

        [Required]
        public int IdUsuario { get; set; }

        [ForeignKey("IdUsuario")]
        public virtual Usuario? Usuario { get; set; }
    }
}
