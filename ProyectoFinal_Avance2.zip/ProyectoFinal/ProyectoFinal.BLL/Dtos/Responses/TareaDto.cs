﻿using System;

namespace ProyectoFinal.BLL.Dtos.Responses
{
    public class TareaDto
    {
        public int IdTarea { get; set; }
        public string? Titulo { get; set; }
        public string? Descripcion { get; set; }
        public string? Prioridad { get; set; }
        public string? Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? FechaEjecucion { get; set; }
        public int IdUsuario { get; set; }
        public string? NombreUsuario { get; set; }
    }
}
