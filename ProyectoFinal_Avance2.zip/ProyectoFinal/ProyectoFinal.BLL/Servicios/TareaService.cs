﻿using Microsoft.EntityFrameworkCore;
using ProyectoFinal.BLL.Dtos.Requests;
using ProyectoFinal.BLL.Dtos.Responses;
using ProyectoFinal.BLL.Interfaces;
using ProyectoFinal.DAL.Context;
using ProyectoFinal.ML.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProyectoFinal.BLL.Servicios
{
    public class TareaService : ITareaService
    {
        private readonly ProyectoFinalDbContext _context;

        public TareaService(ProyectoFinalDbContext context)
        {
            _context = context;
        }

        public async Task<List<TareaDto>> ObtenerTareasAsync()
        {
            return await _context.Tareas
                .Include(t => t.Usuario)
                .Select(t => new TareaDto
                {
                    IdTarea = t.IdTarea,
                    Titulo = t.Titulo,
                    Descripcion = t.Descripcion,
                    Prioridad = t.Prioridad,
                    Estado = t.Estado,
                    FechaCreacion = t.FechaCreacion,
                    FechaEjecucion = t.FechaEjecucion,
                    IdUsuario = t.IdUsuario,
                    NombreUsuario = t.Usuario!.Nombre
                })
                .ToListAsync();
        }

        public async Task<TareaDto?> ObtenerPorIdAsync(int id)
        {
            var t = await _context.Tareas.Include(x => x.Usuario).FirstOrDefaultAsync(t => t.IdTarea == id);
            if (t == null) return null;

            return new TareaDto
            {
                IdTarea = t.IdTarea,
                Titulo = t.Titulo,
                Descripcion = t.Descripcion,
                Prioridad = t.Prioridad,
                Estado = t.Estado,
                FechaCreacion = t.FechaCreacion,
                FechaEjecucion = t.FechaEjecucion,
                IdUsuario = t.IdUsuario,
                NombreUsuario = t.Usuario?.Nombre
            };
        }

        public async Task CrearTareaAsync(TareaCreateDto dto)
        {
            var tarea = new Tarea
            {
                Titulo = dto.Titulo,
                Descripcion = dto.Descripcion,
                Prioridad = dto.Prioridad,
                Estado = dto.Estado,
                FechaEjecucion = dto.FechaEjecucion,
                IdUsuario = dto.IdUsuario
            };

            _context.Tareas.Add(tarea);
            await _context.SaveChangesAsync();
        }

        public async Task ActualizarTareaAsync(int id, TareaCreateDto dto)
        {
            var tarea = await _context.Tareas.FindAsync(id);
            if (tarea == null) return;

            tarea.Titulo = dto.Titulo;
            tarea.Descripcion = dto.Descripcion;
            tarea.Prioridad = dto.Prioridad;
            tarea.Estado = dto.Estado;
            tarea.FechaEjecucion = dto.FechaEjecucion;
            tarea.IdUsuario = dto.IdUsuario;

            await _context.SaveChangesAsync();
        }
    }
}
