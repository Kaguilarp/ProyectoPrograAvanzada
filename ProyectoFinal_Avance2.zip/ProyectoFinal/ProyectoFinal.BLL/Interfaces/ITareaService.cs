﻿using System.Collections.Generic;
using System.Threading.Tasks;
using ProyectoFinal.BLL.Dtos.Requests;
using ProyectoFinal.BLL.Dtos.Responses;

namespace ProyectoFinal.BLL.Interfaces
{
    public interface ITareaService
    {
        Task<List<TareaDto>> ObtenerTareasAsync();
        Task<TareaDto?> ObtenerPorIdAsync(int id);
        Task CrearTareaAsync(TareaCreateDto dto);
        Task ActualizarTareaAsync(int id, TareaCreateDto dto);
    }
}
