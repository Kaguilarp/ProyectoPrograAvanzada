﻿using Microsoft.AspNetCore.Mvc;
using ProyectoFinal.BLL.Interfaces;
using ProyectoFinal.BLL.Dtos.Requests;
using System.Threading.Tasks;

namespace ProyectoFinal.APP.Controllers
{
    public class TareaController : Controller
    {
        private readonly ITareaService _tareaService;

        public TareaController(ITareaService tareaService)
        {
            _tareaService = tareaService;
        }

        public async Task<IActionResult> Index()
        {
            var tareas = await _tareaService.ObtenerTareasAsync(); 

            return View(tareas);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(TareaCreateDto model)
        {
            if (ModelState.IsValid)
            {
                await _tareaService.CrearTareaAsync(model);
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var tarea = await _tareaService.ObtenerPorIdAsync(id);
            if (tarea == null) return NotFound();

            var model = new TareaCreateDto
            {
                Titulo = tarea.Titulo,
                Descripcion = tarea.Descripcion,
                Prioridad = tarea.Prioridad,
                Estado = tarea.Estado,
                FechaEjecucion = tarea.FechaEjecucion,
                IdUsuario = tarea.IdUsuario
            };

            return View(model);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(int id, TareaCreateDto model)
        {
            if (ModelState.IsValid)
            {
                await _tareaService.ActualizarTareaAsync(id, model);
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }
    }
}
