﻿using Microsoft.EntityFrameworkCore;
using ProyectoFinal.ML.Entities;

namespace ProyectoFinal.DAL.Context
{
    public class ProyectoFinalDbContext : DbContext
    {
        public ProyectoFinalDbContext(DbContextOptions<ProyectoFinalDbContext> options) : base(options) { }

        public DbSet<Tarea> Tareas { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
    }
}
